package model;

public class Instructors {

    private String instructorName;
    private int image;

    public Instructors(String instructorName, int image) {
        this.instructorName = instructorName;
        this.image = image;
    }

    public String getInstructorName() {
        return instructorName;
    }

    public void setInstructorName(String instructorName) {
        this.instructorName = instructorName;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

}
