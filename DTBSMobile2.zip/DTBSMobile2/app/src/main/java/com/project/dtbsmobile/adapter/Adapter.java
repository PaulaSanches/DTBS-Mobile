package com.project.dtbsmobile.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.project.dtbsmobile.R;

import java.util.List;

import model.Instructors;

public class Adapter extends RecyclerView.Adapter<Adapter.MyViewHolder> {



    private List<Instructors> instructorsList;

    public Adapter(List<Instructors> list) {
        this.instructorsList = list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View listItem = LayoutInflater.from(parent.getContext())
               .inflate(R.layout.adapter_list, parent, false);


        return new MyViewHolder(listItem);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        Instructors instructors = instructorsList.get(position);
        holder.instructor.setText(instructors.getInstructorName());
        holder.image.setImageResource(instructors.getImage());

    }

    @Override
    public int getItemCount() {

        return instructorsList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView instructor;
        ImageView image;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            instructor = itemView.findViewById(R.id.textInstructor);
            image = itemView.findViewById(R.id.imageInstructor);

            };

        }

    }


