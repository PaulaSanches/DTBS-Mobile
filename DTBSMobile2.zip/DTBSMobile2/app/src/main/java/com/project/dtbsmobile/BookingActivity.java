package com.project.dtbsmobile;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.prolificinteractive.materialcalendarview.CalendarDay;

public class BookingActivity extends AppCompatActivity {

    private TextView textInstructorSelected,textDateSelected,textCustomer,textLicenseNumber,textSummary,textTime;
    CalendarDay dateSelected;
    private Button btBook;
    private RadioGroup radioGroup;
    private RadioButton rb910,rb1011,rb1112, rb121, rb12 , rb23, rb34, rb45;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        textInstructorSelected = findViewById(R.id.textInstructorSelected);
        String instructorSelected = getIntent().getStringExtra("InstructorSelected");
        textInstructorSelected.setText("Instructor: "+instructorSelected);

        textDateSelected = findViewById(R.id.textDateSelected);
        dateSelected = (CalendarDay) this.getIntent().getExtras().get("dateSelected");
        textDateSelected.setText("Date: "+dateSelected.getDay()+"/"+(dateSelected.getMonth()+1)+"/"+dateSelected.getYear()+"");

        textCustomer = findViewById(R.id.textCustomer);
        String username = getIntent().getStringExtra("username");
        textCustomer.setText("Customer: "+username);

        textLicenseNumber = findViewById(R.id.textLicenseNumber);
        String driverlicense = getIntent().getStringExtra("driverlicense");
        textLicenseNumber.setText("License: "+driverlicense);

        btBook = findViewById(R.id.btBook);
        radioGroup = findViewById(R.id.radioGroup);

        rb910 = (RadioButton) findViewById(R.id.rb910);
        rb1011 = (RadioButton) findViewById(R.id.rb1011);
        rb1112 = (RadioButton) findViewById(R.id.rb1112);
        rb121 = (RadioButton) findViewById(R.id.rb121);
        rb12 = (RadioButton) findViewById(R.id.rb12);
        rb23 = (RadioButton) findViewById(R.id.rb23);
        rb34 = (RadioButton) findViewById(R.id.rb34);
        rb45 = (RadioButton) findViewById(R.id.rb45);

        textSummary = findViewById(R.id.textSummary);
        textTime = findViewById(R.id.textTime);

        btBook.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            int selectedId = radioGroup.getCheckedRadioButtonId();

                                            // find which radioButton is checked by id
                                            if(selectedId == rb910.getId()) {
                                                textTime.setText("Time: 9:00 am - 10:00 am");
                                            } else if(selectedId == rb1011.getId()) {
                                                textTime.setText("Time: 10:00 am - 11:00 am");
                                            } else if(selectedId == rb1112.getId()) {
                                                textTime.setText("Time: 11:00 am - 12:00 am");
                                            } else if(selectedId == rb121.getId()) {
                                                textTime.setText("Time: 12:00 am - 1:00 pm");
                                            } else if(selectedId == rb12.getId()) {
                                                textTime.setText("Time: 1:00 pm - 3:00 pm");
                                            } else if(selectedId == rb23.getId()) {
                                                textTime.setText("Time: 2:00 pm - 3:00 pm");
                                            } else if(selectedId == rb34.getId()) {
                                                textTime.setText("Time: 3:00 pm - 4:00 pm");
                                            } else if(selectedId == rb45.getId()) {
                                                textTime.setText("Time: 4:00 pm - 5:00 pm");
                                            }

                                            textTime.setVisibility(View.VISIBLE);
                                            textSummary.setVisibility(View.VISIBLE);

                                            btBook.setVisibility(View.INVISIBLE);
                                            radioGroup.setVisibility(View.INVISIBLE);

                                        }

        });

    }
}

