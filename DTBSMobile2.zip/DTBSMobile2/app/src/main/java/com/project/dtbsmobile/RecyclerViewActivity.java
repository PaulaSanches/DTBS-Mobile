package com.project.dtbsmobile;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.project.dtbsmobile.adapter.Adapter;
import com.prolificinteractive.materialcalendarview.CalendarDay;

import java.util.ArrayList;
import java.util.List;

import model.Instructors;

public class RecyclerViewActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<Instructors> Instructorslist = new ArrayList<>();
    CalendarDay dateSelected;
    String username,driverlicense;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recyclerview);

        dateSelected = (CalendarDay) this.getIntent().getExtras().get("Date");
        username = (String) this.getIntent().getExtras().get("username");
        driverlicense = (String) this.getIntent().getExtras().get("driverlicense");


        recyclerView = findViewById(R.id.recyclerView);

        //Instructors list
        this.instructorsCreate();

        //set adapter
        Adapter adapter = new Adapter(Instructorslist);

        //set Recycler View
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayout.VERTICAL));
        recyclerView.setAdapter(adapter);

        //click event
        recyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(
                        getApplication().getApplicationContext(),
                        recyclerView,
                        new RecyclerItemClickListener.OnItemClickListener() {
                            @Override
                            public void onItemClick(View view, int position) {
                                Intent intent = new Intent(RecyclerViewActivity.this, BookingActivity.class);
                                intent.putExtra("InstructorSelected",Instructorslist.get(position).getInstructorName());
                                intent.putExtra("dateSelected",dateSelected);
                                intent.putExtra("username",username);
                                intent.putExtra("driverlicense",driverlicense);
                                startActivity(intent);
                            }

                            @Override
                            public void onLongItemClick(View view, int position) {

                            }

                            @Override
                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                            }
                        }
                )
        );

    }

    public void instructorsCreate() {

        Instructors instructors = new Instructors("Blanch Courtney", R.drawable.image2);
        Instructorslist.add(instructors);

        instructors = new Instructors("Jamie Turnbull",R.drawable.image3);
        Instructorslist.add(instructors);

        instructors = new Instructors("Joshua Woods", R.drawable.image4);
        Instructorslist.add(instructors);

        instructors = new Instructors("Joy Bella",R.drawable.image5);
        Instructorslist.add(instructors);

        instructors = new Instructors("Patrick Swan",R.drawable.image6);
        Instructorslist.add(instructors);

        instructors = new Instructors("Paul Martin",R.drawable.image7);
        Instructorslist.add(instructors);

        instructors = new Instructors("Phil Brown",R.drawable.image8);
        Instructorslist.add(instructors);

        instructors = new Instructors("Robert Newman",R.drawable.image9);
        Instructorslist.add(instructors);

        instructors = new Instructors("Taryn Wilken",R.drawable.image10);
        Instructorslist.add(instructors);

        instructors = new Instructors("Phillipe Anselmo", R.drawable.image11);
        Instructorslist.add(instructors);

    }
}