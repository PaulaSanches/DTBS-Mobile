package com.project.dtbsmobile;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.CalendarMode;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;
import com.prolificinteractive.materialcalendarview.OnDateSelectedListener;

import java.util.Calendar;


public class CalendarActivity extends AppCompatActivity {

    private MaterialCalendarView calendarView;
    public EditText textname, textlicenseNumber;
    public FloatingActionButton viewSlotsbtn;

    private DatabaseReference mDatabase;

    CalendarDay dateSelected;
    String username,driverlicense;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        FirebaseUser userDb = FirebaseAuth.getInstance().getCurrentUser();

        calendarView = findViewById(R.id.calendarView);
        viewSlotsbtn = findViewById(R.id.viewSlotsbtn);

        textname = findViewById(R.id.textname);
        textlicenseNumber = findViewById(R.id.textlicenseNumber);
        //textname.setText(userDb.getUid());

        mDatabase = FirebaseDatabase.getInstance().getReference().child("users").child(userDb.getUid()).child("name");
        mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                username = dataSnapshot.getValue().toString();
                textname.setText(username);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                textname.setText("data not get" + databaseError );
            }
        });

        mDatabase = FirebaseDatabase.getInstance().getReference().child("users").child(userDb.getUid()).child("driverlicense");
        mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                driverlicense = dataSnapshot.getValue().toString();
                textlicenseNumber.setText(driverlicense);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                textlicenseNumber.setText("data not get" + databaseError );
            }
        });



        viewSlotsbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), RecyclerViewActivity.class);
                intent.putExtra("Date",dateSelected);
                intent.putExtra("username",username);
                intent.putExtra("driverlicense",driverlicense);
                startActivity(intent);
            }

        });

        calendarView.state().edit()
                .setFirstDayOfWeek(Calendar.MONDAY)
                .setCalendarDisplayMode(CalendarMode.MONTHS)
                .setMinimumDate(CalendarDay.from(2021,1, 1))
                .setMaximumDate(CalendarDay.from(2022, 12, 31))
                .commit();

        calendarView.setOnDateChangedListener(new OnDateSelectedListener() {
            @Override
            public void onDateSelected(@NonNull MaterialCalendarView widget, @NonNull CalendarDay date, boolean selected) {
                Log.i("date: ", "value: " + date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getYear() );
                dateSelected = date;
            }
            });
    }
}
